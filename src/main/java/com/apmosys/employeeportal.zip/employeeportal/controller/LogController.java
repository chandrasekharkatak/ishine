package com.apmosys.employeeportal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.apmosys.employeeportal.dto.LogDTO;
import com.apmosys.employeeportal.service.LogService;
import com.apmosys.employeeportal.utility.ServiceResponse;

@RestController
@RequestMapping(path = "/api")
public class LogController {

	@Autowired
	LogService logService;

	@RequestMapping(value = "/setSessionInfo", method = RequestMethod.POST)
	public ServiceResponse setSessionInfo(@RequestBody LogDTO logDTO) {

		ServiceResponse response = logService.setSessionInfo(logDTO);
		return response;
	}
}
