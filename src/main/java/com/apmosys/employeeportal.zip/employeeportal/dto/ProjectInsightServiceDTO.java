package com.apmosys.employeeportal.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ProjectInsightServiceDTO {

    private String service;
    private List<ProjectInsightSubServiceDTO> subServiceList;
    
}