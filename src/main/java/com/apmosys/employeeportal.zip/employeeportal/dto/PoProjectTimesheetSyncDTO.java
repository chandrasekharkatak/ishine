package com.apmosys.employeeportal.dto;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PoProjectTimesheetSyncDTO {
	
	private Long poProjectId;
    private String ishineStoredProjectName;
    private String ishineStoredPoNo;
    private List<PoTeamTimesheetSyncDTO> teamDetails;

}
