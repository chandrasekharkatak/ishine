package com.apmosys.employeeportal.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ProjectInsightSubServiceDTO {

    private String subService;
    private List<ProjectInsightSubServiceDTO> subServiceChildren;
    
}